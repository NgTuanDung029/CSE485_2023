<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Route: /tacgia</h2>
    <h4>/tacgia/them</h4>
    <h4>/tacgia/thongtin/{id}</h4>
    <h4>/tacgia/thongtin/{id}/chinhsua</h4>
    <h4>/tacgia/thongtin/{id}/xoa</h4>
    <h2>Route: /theloai</h2>
    <h4>/theloai/them</h4>
    <h4>/theloai/thongtin/{id}</h4>
    <h4>/theloai/thongtin/{id}/chinhsua</h4>
    <h4>/theloai/thongtin/{id}/xoa</h4>
</body>
</html>
