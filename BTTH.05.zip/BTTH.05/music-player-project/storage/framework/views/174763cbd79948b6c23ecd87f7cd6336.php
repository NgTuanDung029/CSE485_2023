<?php $__env->startSection('title', 'Danh sách tác giả'); ?>
<?php $__env->startSection('name', 'Quản Lý Tác Giả'); ?>
<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('tacgia.them')); ?>" class="btn btn-success mb-2">Thêm mới tác giả</a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Mã tác giả</th>
                <th scope="col">Tên tác giả</th>
                <th scope="col">Hình ảnh</th>
                <th scope="col">Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ds_tacgia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tacgia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e(count($ds_tacgia) - $key); ?></th>
                    <td><?php echo e($tacgia->ten_tgia); ?></td>
                    <td><img src="<?php echo e($tacgia->hinh_tgia); ?>" style="width: 100px; height: 100px"></td>
                    <td>
                        <a href="<?php echo e(route('tacgia.thongtin', $tacgia->ma_tgia)); ?>" class="btn btn-warning">Xem</a>
                        <a href="<?php echo e(route('tacgia.sua', $tacgia->ma_tgia)); ?>" class="btn btn-primary">Sửa</a>
                        <a href="<?php echo e(route('tacgia.xoa', $tacgia->ma_tgia)); ?>" class="btn btn-danger">Xóa</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Practise\CSE485_CongNgheWeb\BTTH.05\music-player-project\resources\views/tacgia/index.blade.php ENDPATH**/ ?>