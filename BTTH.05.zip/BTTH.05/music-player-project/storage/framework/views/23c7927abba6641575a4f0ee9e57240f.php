<?php $__env->startSection('title', 'Chỉnh sửa tác giả'); ?>
<?php $__env->startSection('name', 'Chỉnh sửa tác giả'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('tacgia.capnhat', $tacgia->ma_tgia)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="ma_tgia">Mã tác giả</label>
        <input type="text" name="ma_tgia" value="<?php echo e($tacgia->ma_tgia); ?>" class="form-control">
    </div>
    <div class="form-group">
        <label for="ten_tgia">Tên tác giả</label>
        <input type="text" name="ten_tgia" value="<?php echo e($tacgia->ten_tgia); ?>" class="form-control">
    </div>
    <div class="form-group">
        <label for="hinh_tgia">Hình ảnh của tác giả</label>
        <input type="text" name="hinh_tgia" value="<?php echo e($tacgia->hinh_tgia); ?>" class="form-control">
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Practise\CSE485_CongNgheWeb\BTTH.05\music-player-project\resources\views/tacgia/chinhsua.blade.php ENDPATH**/ ?>