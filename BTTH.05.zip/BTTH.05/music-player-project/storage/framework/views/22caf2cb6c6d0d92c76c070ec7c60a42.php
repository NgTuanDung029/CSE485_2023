<form action="<?php echo e(route('theloai.luu')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="ten_tloai">Tên thể loại</label>
        <input type="text" name="ten_tloai" value="" class="form-control">
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Thêm mới</button>
    </div>
</form>
<?php /**PATH C:\laragon\www\Practise\CSE485_CongNgheWeb\BTTH.05\music-player-project\resources\views/theloai/them.blade.php ENDPATH**/ ?>