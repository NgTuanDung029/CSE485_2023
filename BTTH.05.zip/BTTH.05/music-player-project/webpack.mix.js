const mix = require('laravel-mix');

mix.css('resources/css/bootstrap.css', 'public/css')
   .js('resources/js/bootstrap.js', 'public/js');
